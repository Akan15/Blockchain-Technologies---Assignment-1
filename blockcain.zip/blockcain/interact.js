const {Web3} = require('web3');


const web3 = new Web3('http://127.0.0.1:7545');


const contractABI = [
    {
        "inputs": [],
        "name": "getBalance",
        "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "withdrawAll",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "stateMutability": "payable",
        "type": "receive"
    }
];

const contractAddress = "0x7f1A684ca3Bfe08B54415A407714B9aB35548B68"; 

const interact = async () => {
    const accounts = await web3.eth.getAccounts();
    const contract = new web3.eth.Contract(contractABI, contractAddress);


    const balance = await contract.methods.getBalance().call();
    console.log('Баланс контракта:', web3.utils.fromWei(balance, 'ether'), 'ETH');


    await contract.methods.withdrawAll().send({ from: accounts[0] });
    console.log('Средства выведены!');
};

interact();

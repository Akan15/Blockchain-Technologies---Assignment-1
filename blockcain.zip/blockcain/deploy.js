const {Web3} = require('web3');


const web3 = new Web3('http://127.0.0.1:7545');

const deploy = async () => {
    const accounts = await web3.eth.getAccounts(); 
    console.log('Деплой осуществляется с аккаунта:', accounts[0]);

   
    const contractABI = [
        {
            "inputs": [],
            "name": "getBalance",
            "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "withdrawAll",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "stateMutability": "payable",
            "type": "receive"
        }
    ];

    const contractBytecode =
        "0x608060405234801561001057600080fd5b50336000806101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff16021790555061030b806100606000396000f3fe6080604052600436106100385760003560e01c806312065fe014610044578063853828b61461006f5780638da5cb5b146100865761003f565b3661003f57005b600080fd5b34801561005057600080fd5b506100596100b1565b604051610066919061026d565b60405180910390f35b34801561007b57600080fd5b506100846100b9565b005b34801561009257600080fd5b5061009b6101b0565b6040516100a89190610232565b60405180910390f35b600047905090565b60008054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff1614610147576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040161013e9061024d565b60405180910390fd5b60008054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166108fc479081150290604051600060405180830381858888f193505050501580156101ad573d6000803e3d6000fd5b50565b60008054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b6101dd81610299565b82525050565b60006101f0601783610288565b91507f4f6e6c79206f776e65722063616e2077697468647261770000000000000000006000830152602082019050919050565b61022c816102cb565b82525050565b600060208201905061024760008301846101d4565b92915050565b60006020820190508181036000830152610266816101e3565b9050919050565b60006020820190506102826000830184610223565b92915050565b600082825260208201905092915050565b60006102a4826102ab565b9050919050565b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b600081905091905056fea2646970667358221220d0a4f9a9889ed8bbdab28ecc40c2da6abfea008a0fa919250c67a55fda8479e164736f6c63430008000033";

    const contract = new web3.eth.Contract(contractABI);

    const deployedContract = await contract
        .deploy({ data: contractBytecode })
        .send({ from: accounts[0], gas: '1000000' });

    console.log('Контракт задеплоен по адресу:', deployedContract.options.address);
};

deploy();
